data = [
    {"round": "First"},
    {"round" : "Second"},
    {"round" : "Third"},
    {"round" : "Fourth"},
    {"round" : "Quarters"},
    {"round" : "Semi"},
    {"round" : "Finals"},
    {"year" : "2006", "round" : "Second", "total1" : 136, "img" : "Images/2006.png", "aces": 10, "Doubles" : 4, "firsts": 188, "secs" : 156},
    {"year" : "2007", "round" : "Third", "total1" : 99, "img" : "Images/2007.png", "aces": 4, "Doubles" : 2, "firsts": 186, "secs" : 145},
    {"year" : "2008", "round" : "Second", "total1" : 113, "img" : "Images/2008.png", "aces": 9, "Doubles" : 3, "firsts": 186, "secs" : 145},
    {"year" : "2009", "round" : "Third", "total1" : 136, "img" : "Images/2009.png", "aces": 9, "Doubles" : 3, "firsts": 187, "secs" : 146},
    {"year" : "2010", "round" : "Third", "total1" : 129, "img" : "Images/2010.png", "aces": 11, "Doubles" : 6, "firsts": 188, "secs" : 146},
    {"year" : "2011", "round" : "Quarters", "total1" : 90, "img" : "Images/2011.png", "aces": 1, "Doubles" : 0, "firsts": 184, "secs" : 144},
    {"year" : "2012", "round" : "Third", "total1" : 116, "img" : "Images/2012.png", "aces": 4, "Doubles" : 2, "firsts": 173, "secs" : 133},
    {"year" : "2013", "round" : "Fourth", "total1" : 209, "img": "Images/2013.png", "aces": 16, "Doubles" : 2, "firsts": 194, "secs" : 158},
    {"year" : "2014", "round" : "Finals", "total1" : 116, "img" : "Images/2014.png", "aces": 19, "Doubles" : 2, "firsts": 162, "secs" : 134}
]



var margin = {
    top: 100, //20
    right: 20 ,//20,
    bottom: 60, //30
    left: 80 //40
}, width = 1500-margin.left-margin.right
, height = 500-margin.top-margin.bottom;



// format the data
data.forEach(function (d) {
    parseyear = d3.timeParse("%Y");
    d.year = parseyear(d.year);
    d.round = d.round;
    d.aces = +d.aces;
    d.Doubles = +d.Doubles;
    d.firsts = +d.firsts;
    d.secs = +d.secs;
});

//sort the data by year so the trend line makes sense
data.sort(function (a, b) {
    return a.year - b.year;
});

// set the ranges
var x = d3.scaleTime().range([0, width-1000]);
// var y = d3.scaleLinear().range([height, 0]);
var y = d3.scaleOrdinal().range([height, height*5/6, height*4/6, height*3/6, height*2/6, height*1/6,0]);


// Scale the range of the data
    x.domain(d3.extent(data, function (d) {
        return d.year;
    }));
// y.domain([0, d3.max(data, function (d) {
//     return d.round;
// })]);
    y.domain(data.map(function (d) {
        return d.round;
    }));
// define the line
var valueline = d3.line()
 .defined(function(d) {
        return d.year !== null;
    })
    .x(function (d) {
        return x(d.year);
    })
    .y(function (d) {
        return y(d.round);
    });
// append the svg object to the body of the page
var svg = d3.select("#scatter").append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
    .append("g")
    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

// Add the trendline
svg.append("path")
    .data([data])
    .attr("class", "line")
    .attr("d", valueline)
    .attr("stroke", "#32CD32")
    .attr("stroke-width", 2)
    .attr("fill", "#FFFFFF");

// Add the data points
var path = svg.selectAll("dot")
    .data(data)
    .enter().append("circle")
    .attr("r", 7)
    .attr("cx", function (d) {
        return x(d.year);
    })
    .attr("cy", function (d) {
        return y(d.round);
    })
    .attr("stroke", "black")
    .attr("stroke-width", 1.5)
    .attr("fill", "#FFFFFF")
    .on('mouseover', function (d, i) {
        d3.select(this).attr("r", 20);
        svg.append("image")
            .attr("class", "img")
            .attr('xlink:href', d.img)
            .attr('transform', 'translate('+ 400 + ','+50+')')
            .attr("width", 440)
            .attr("height", 300)
            .style("display", "inline");
        // 430, 20
        // d3.select(this).transition()
        //     .duration('100')
        //     .attr("r", 7);
        // div.transition()
        //     .duration(100)
        //     .style("opacity", 1);
        // div.html((d.round))
        //     .style("left", "1000px")
        //     .style("top", "1000px");
    })
    .on('mouseout', function (d, i) {
        d3.select(this).attr("r", 7)
            .style("fill", function(d) {
                console.log(d.year)
                if (d.year == "Wed Jan 01 2014 00:00:00 GMT-0700 (Mountain Standard Time)") {
                    
                    return "green"
                }
                else{
                    
                    return "red"
                }
            });
        svg.select("image").remove();
        // div.transition()
        //     .duration('200')
        //     .style("opacity", 0);
    });

// Add the axis
if (width < 500) {
    svg.append("g")
        .attr("transform", "translate(0," + height + ")")
        .call(d3.axisBottom(x).ticks(5));
       
} else {
    svg.append("g")
        .attr("transform", "translate(0," + height + ")")
        .call(d3.axisBottom(x));
          
}
svg.append("text")
  .attr("class", "xlabel")
.attr("text-anchor", "middle")
  .attr("x", width / 2 -470)
  .attr("y", height + margin.bottom -10)
  .attr("font-size", "15px")
  .text("Year");
// var rs = ["First", "Second", "Third", "Fourth", "Quarters", "Semi", "Finals"];
svg.append("g")
    .call(d3.axisLeft(y).tickFormat(function (d) {
        console.log(d)
        return d 
    }))
    .append("text")
        .attr("class", "ylabel")
        .attr("transform", "rotate(-90)")
        .attr("x", -200)
        .attr("y", -90)
        .attr("dy", "2em")
        .style("text-anchor", "middle")
        .attr("fill", "Black")
        .attr("font-size", "15px")
        .text("Rounds");

svg.append("text")
       .attr("x", 200)            
       .attr("y", 0 - (margin.top / 2 - 30))
       .attr("text-anchor", "middle")  
       .style("font-size", "20px")
       .attr("font-weight", "bold")
       .text("Round vs Year");

var x2 = d3.scaleTime().range([870, width-70]);
var y2 = d3.scaleLinear().range([height, 0]);

var valueline1 = d3.line()
.defined(function(d) {
        return d.year !== null;
    })
    .x(function(d) { return x2(d.year); })
    .y(function (d) { return y2(d.aces); });

//2nd line
var valueline2 = d3.line()
.defined(function(d) {
        return d.year !== null;
    })
    .x(function(d) {return x2(d.year); })
    .y(function(d) {return y2(d.Doubles); });

x2.domain(d3.extent(data, function(d) { return d.year; }));
y2.domain([0, d3.max(data, function(d) { return Math.max(d.aces, d.Doubles); })]);

svg.append("g")
    .attr("width", "300")
    .attr("height", "600")
    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");


svg.append("path")
    .data([data])
    .attr("class", "line")
    .style("stroke", "blue")
    .attr("d", valueline1);

svg.append("path")
    .data([data])
    .attr("class", "line")
    .style("stroke", "green")
    .attr("d", valueline2);

var tool_tip1 = d3.tip()
    .attr("class", "d3-tip")
    .offset([-8, 0])
    .html(function(d){
        return "<p>Avg 1st serve speed: " + d.firsts + "</p>"; 
    });
svg.call(tool_tip1);

var tool_tip2 = d3.tip()
    .attr("class", "d3-tip")
    .offset([-8, 0])
    .html(function(d) {
        return  "<p> Avg 2nd serve speed: " + d.secs + "</p";
    });
svg.call(tool_tip2)


var path = svg.selectAll("dot")
    .data(data)
    .enter().append("circle")
    .attr("r", 7)
    .attr("cx", function(d) {
        return x2(d.year);
    })
    .attr("cy", function(d) {
        return y2(d.aces);
    })
    .attr("stroke", "black")
    .attr("stroke-width", 1.5)
    .style("fill", function(d) {
                console.log(d.year)
                if (d.year == "Wed Jan 01 2014 00:00:00 GMT-0700 (Mountain Standard Time)") {
                    
                    return "green"
                }
                else{
                    
                    return "red"
                }
            })
    .on('mouseover', tool_tip1.show)
    .on('mouseout', tool_tip1.hide);

var path = svg.selectAll("dot")
    .data(data)
    .enter().append("circle")
    .attr("r", 7)
    .attr("cx", function(d) {
        return x2(d.year);
    })
    .attr("cy", function(d) {
        return y2(d.Doubles);
    })
    .attr("stroke", "black")
    .attr("stroke-width", 1.5)
    .style("fill", function(d) {
                console.log(d.year)
                if (d.year == "Wed Jan 01 2014 00:00:00 GMT-0700 (Mountain Standard Time)") {
                    
                    return "green"
                }
                else{
                    
                    return "red"
                }
            })
    .on('mouseover', tool_tip2.show)
    .on('mouseout', tool_tip2.hide);


svg.append("g")
    .attr("transform", "translate(0, " + height + ")")
    .call(d3.axisBottom(x2));

svg.append("text")
  .attr("class", "xlabel")
.attr("text-anchor", "middle")
  .attr("x", width - 300)
  .attr("y", height + margin.bottom -10)
  .text("Year");

svg.append("g")
    .attr("transform", "translate(870, " + 0 + ")")

    .call(d3.axisLeft(y2));

svg.append("text")
       .attr("x", width-300)            
       .attr("y", 0 - (margin.top / 2 - 30))
       .attr("text-anchor", "middle")  
       .style("font-size", "20px")
       .attr("font-weight", "bold")
       .text("Aces and Double Faults");
var a1 = ["Aces", "Doubles"];

var legend = svg.append("g")
    .attr("class", "legend");

legend.append('rect')
    .attr('x', width-50)
    .attr('y', -30)
    .attr("width", 10)
    .attr("height", 10)
    .style('fill', "blue");
legend.append('text')
    .attr('x', width-30)
    .attr('y', -22)
    .text("Aces");

var legend2 = svg.append("g")
    .attr("class", "legend");
legend2.append("rect")
    .attr('x', width-50)
    .attr('y', -10)
    .attr("width", 10)
    .attr("height", 10)
    .style("fill", "green");
legend2.append("text")
    .attr("x", width-30)
    .attr("y", -2)
    .text("Double");


